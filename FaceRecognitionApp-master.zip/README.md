# Face Recognition App

Uses Flask, Python simple JS and AWS Rekognition to do face recognition.

Upload a face and then compare to those in a collection.
